# ABOUTME: Runs process-boundary checks under an owned disposable service account.
# ABOUTME: Removes its account and private fixtures after exporting safe test evidence.
from pathlib import Path
import hashlib
import json
import os
import pwd
import shutil
import subprocess
import tarfile
import time

cache = Path(__file__).parent
home = Path('/var/tmp/lifeos-073-20261016-account')
name = 'lifeos-073-test'
created = False
receipt = {'status': 'FAIL', 'account': name, 'product_policy_changed': False,
    'test_assertions_changed': False, 'production_profile_used': False}

def run(*command, check=True):
    result = subprocess.run(command, capture_output=True, text=True, timeout=180)
    if check and result.returncode:
        raise RuntimeError(f'{command[0]} failed: {result.stderr.strip()}')
    return result

try:
    if os.getuid() != 0:
        raise RuntimeError('The disposable account operator requires root')
    try:
        pwd.getpwnam(name)
    except KeyError:
        pass
    else:
        raise RuntimeError('The account already exists')
    if home.exists():
        raise RuntimeError('The disposable home already exists')
    run('useradd', '--create-home', '--home-dir', str(home), '--shell', '/usr/sbin/nologin', '--user-group', name)
    created = True
    account = pwd.getpwnam(name)
    receipt['uid'] = account.pw_uid
    root = home / 'source'
    root.mkdir(mode=0o700)
    with tarfile.open(cache / 'boundary-source.tar') as archive:
        archive.extractall(root, filter='data')
    original = Path('/home/outsider/.cache/lifeos-daily-promotion-20261014')
    runtime = original / 'test-home/.hermes/tools/python-3.14.7+20260901-linux-x64'
    run('cp', '-a', '--reflink=auto', str(runtime), str(home / 'python'))
    run('cp', '-a', '--reflink=auto', str(original / 'frozen-test-environment'), str(home / 'venv'))
    run('cp', '-a', '--reflink=auto', '/home/outsider/.cache/lifeos-release-0.7.3-20261016/packages/0.7.3-99e18c44/hermes', str(home / 'hermes'))
    for command in ('python', 'python3', 'python3.14'):
        path = home / 'venv/bin' / command
        if path.exists() or path.is_symlink():
            path.unlink()
        path.symlink_to(home / 'python/bin/python3.14')
    (home / 'venv/pyvenv.cfg').write_text(f'home = {home}/python/bin\ninclude-system-site-packages = false\nversion = 3.14.7\nrelocatable = true\n')
    binary = home / '.local/bin/bun'
    binary.parent.mkdir(parents=True, mode=0o700)
    shutil.copy2(Path('/home/outsider/.cache/lifeos-pulse-editor-20261014/tool-bin/bun').resolve(), binary)
    for directory, dirs, files in os.walk(home):
        os.chown(directory, account.pw_uid, account.pw_gid)
        for entry in dirs + files:
            os.chown(Path(directory) / entry, account.pw_uid, account.pw_gid, follow_symlinks=False)
    run('loginctl', 'enable-linger', name)
    run('systemctl', 'start', f'user@{account.pw_uid}.service')
    bus = Path(f'/run/user/{account.pw_uid}/bus')
    for attempt in range(30):
        if bus.exists():
            break
        time.sleep(0.5)
    if not bus.exists():
        raise RuntimeError('The disposable user manager did not start')
    paths = ['tests/test_removal_consumers.py', 'tests/test_removal_coordinator.py',
        'tests/test_profile_services.py', 'tests/profile_service_writer.py',
        'optional/lifeos_release_manager/removal_consumers.py', 'lifeos_hook_bridge/profile_services.py']
    digest = lambda path: hashlib.sha256((root / path).read_bytes()).hexdigest()
    before = {path: digest(path) for path in paths}
    receipt['test_source_sha256'] = before
    profile = home / 'profile'
    profile.mkdir(mode=0o700)
    os.chown(profile, account.pw_uid, account.pw_gid)
    command = ['runuser', '-u', name, '--', 'env', f'HOME={home}', f'HERMES_HOME={profile}',
        f'XDG_RUNTIME_DIR=/run/user/{account.pw_uid}',
        f'DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/{account.pw_uid}/bus',
        'PYTHONDONTWRITEBYTECODE=1', f'PATH={home}/.local/bin:/usr/bin:/bin',
        f'PYTHONPATH={root}:{root}/tests:{home}/hermes', str(home / 'venv/bin/python'),
        '-W', 'error::ResourceWarning', '-B', '-m', 'unittest', '-v',
        'test_removal_consumers', 'test_removal_coordinator']
    receipt['command'] = command
    with (cache / 'primary-boundary.stdout').open('w') as stdout, (cache / 'primary-boundary.stderr').open('w') as stderr:
        result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr, timeout=300)
    diagnostics = (cache / 'primary-boundary.stderr').read_text()
    receipt.update(exit=result.returncode, source_bytes_unchanged=all(digest(path) == value for path, value in before.items()))
    if result.returncode == 0 and 'Ran 8 tests' in diagnostics and diagnostics.rstrip().endswith('OK') and 'skipped=' not in diagnostics and receipt['source_bytes_unchanged']:
        receipt['status'] = 'PASS'
except Exception as error:
    receipt.update(error_type=type(error).__name__, error=str(error), exit=1)
finally:
    if created:
        run('loginctl', 'disable-linger', name, check=False)
        run('loginctl', 'terminate-user', name, check=False)
        run('userdel', '--remove', name, check=False)
        try:
            pwd.getpwnam(name)
        except KeyError:
            receipt['account_removed'] = True
        else:
            receipt['account_removed'] = False
        receipt['home_removed'] = not home.exists()
        receipt['linger_removed'] = not (Path('/var/lib/systemd/linger') / name).exists()
    target = cache / 'primary-boundary.json'
    target.write_text(json.dumps(receipt, indent=2) + '\n')
    (cache / 'primary-boundary.done').write_text(str(receipt.get('exit', 1)) + '\n')
    for path in [target, cache / 'primary-boundary.done', cache / 'primary-boundary.stdout', cache / 'primary-boundary.stderr']:
        if path.exists():
            os.chown(path, cache.stat().st_uid, cache.stat().st_gid)
raise SystemExit(0 if receipt['status'] == 'PASS' and receipt.get('account_removed') and receipt.get('home_removed') and receipt.get('linger_removed') else 1)
