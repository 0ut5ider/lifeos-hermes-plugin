# ABOUTME: Finds syntactically unused imports and module-level private names in Python files.
# ABOUTME: Reports candidates only; callers must prove dead code with repository-wide references.
import ast, sys, re
from pathlib import Path

def names_used(tree):
    used = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            used.add(node.id)
        elif isinstance(node, ast.Attribute):
            pass
    # string annotations
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            for tok in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", node.value):
                used.add("str:" + tok)
    return used

def all_list(tree):
    out = set()
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "__all__" for t in node.targets):
            for elt in getattr(node.value, "elts", []):
                if isinstance(elt, ast.Constant):
                    out.add(elt.value)
    return out

for path in sys.argv[1:]:
    src = Path(path).read_text()
    tree = ast.parse(src)
    used = names_used(tree)
    exported = all_list(tree)
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.ImportFrom) and node.module == "__future__":
                continue
            for alias in node.names:
                name = (alias.asname or alias.name).split(".")[0]
                if alias.name == "*":
                    continue
                if name not in used and name not in exported:
                    flag = " (str-ref)" if "str:" + name in used else ""
                    print(f"IMPORT {path}:{node.lineno} {name}{flag}")
    # module-level private defs
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.name.startswith("_") and not node.name.startswith("__"):
            if node.name not in used:
                print(f"PRIVDEF {path}:{node.lineno} {node.name}")
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and t.id.startswith("_") and not t.id.startswith("__") and t.id not in used:
                    print(f"PRIVVAR {path}:{node.lineno} {t.id}")
