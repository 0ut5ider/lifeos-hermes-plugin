# ABOUTME: Finds module-level names bound more than once (duplicate imports or redefinitions).
# ABOUTME: Ignores conditional fallback imports inside try or if blocks.
import ast, sys, collections
for f in open(sys.argv[1]).read().split():
    tree = ast.parse(open(f).read())
    seen = collections.defaultdict(list)
    for node in tree.body:
        names = []
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names = [(a.asname or a.name).split('.')[0] for a in node.names]
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names = [node.name]
        for n in names: seen[n].append(node.lineno)
    for n, lines in seen.items():
        if len(lines) > 1: print(f"REDEF {f} {n} {lines}")
    # function-level imports already imported at module level
    top = {n for n in seen}
    for fn in ast.walk(tree):
        if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for node in ast.walk(fn):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    for a in node.names:
                        n = (a.asname or a.name).split('.')[0]
                        if n in top and isinstance(node, ast.Import): print(f"INNERDUP {f}:{node.lineno} {n}")
