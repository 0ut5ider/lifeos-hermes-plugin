#!/bin/bash
# ABOUTME: Runs focused LifeOS bridge unittest modules with the 0.7.2 qualification environment.
# ABOUTME: Uses the worktree code and the prepared 0.7.2 Hermes and native LifeOS fixtures read-only.
set -u
W=${RC_TREE:-/home/outsider/.cache/lifeos-code-cleanup-20261016/runtime-cleanup}
PKG=/home/outsider/.cache/lifeos-release-0.7.2-20261016/packages/0.7.2-b257d29f
BASE=/home/outsider/.cache/lifeos-daily-promotion-20261014
NATIVE=/home/outsider/.cache/lifeos-release-0.5.0-20261014/candidate-fixture-04efe633/account/.hermes/.lifeos-releases/6118299dea37462094bcb7d411effb73/reference-home/.claude
PY=$BASE/frozen-test-environment/bin/python
cd "$W"
env TZ=UTC PYTHONDONTWRITEBYTECODE=1 \
  PATH=/home/outsider/.cache/lifeos-pulse-editor-20261014/tool-bin:$PATH \
  PYTHONPATH="$W:$W/tests:$PKG/hermes" \
  LIFEOS_HERMES_SOURCE=$PKG/hermes LIFEOS_MEMORY_SOURCE=$NATIVE \
  LIFEOS_TASK_HOOK_PATH=$NATIVE/hooks/TaskGovernance.hook.ts LIFEOS_FRESH_SOURCE=$PKG/lifeos \
  LIFEOS_TAB_STATE_SOURCE=$NATIVE LIFEOS_LATEST_HERMES_SOURCE=$BASE/upstream-hermes LIFEOS_HARVEST_CONTROL_SOURCE=$BASE/control-lifeos-install \
  LIFEOS_HERMES_REBUILD_SOURCE=$PKG/hermes LIFEOS_MANAGED_REFERENCE=$NATIVE \
  LIFEOS_MANAGED_FRESH_OPERATION=$BASE/historical-fixture-040/account/.hermes/.lifeos-releases/98ecab3f82ed4689a59a965a04ba7b2c \
  LIFEOS_MANAGED_TEMPLATE_ORIGINALS=$(dirname $(dirname $NATIVE))/fresh-templates/template-originals \
  LIFEOS_TEST_PYTHON=$PY PYTHON=$PY \
  "$PY" -W error::ResourceWarning -m unittest -v "$@"
