# ABOUTME: Finds statements that follow return, raise, continue, or break in the same block.
# ABOUTME: Also reports redundant pass statements and bare constant expressions.
import ast, sys
for f in open(sys.argv[1]).read().split():
    tree = ast.parse(open(f).read())
    for node in ast.walk(tree):
        for field in ("body", "orelse", "finalbody"):
            block = getattr(node, field, None)
            if not isinstance(block, list): continue
            for i, st in enumerate(block[:-1]):
                if isinstance(st, (ast.Return, ast.Raise, ast.Continue, ast.Break)):
                    print(f"UNREACH {f}:{block[i+1].lineno}")
            if len(block) > 1 and any(isinstance(s, ast.Pass) for s in block):
                print(f"PASS {f}:{[s.lineno for s in block if isinstance(s, ast.Pass)]}")
