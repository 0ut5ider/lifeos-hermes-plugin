# ABOUTME: Counts repository references to module-level names defined in owned bridge modules.
# ABOUTME: Lists names referenced only by their own definition, or only inside tests.
import ast, sys, subprocess, re, collections
owned = open(sys.argv[1]).read().split()
files = [f for f in subprocess.run(["git","ls-files"],capture_output=True,text=True).stdout.split()
         if not f.startswith(("docs/verification/","docs/agents/","docs/history/")) and not f.endswith((".lock",".png",".jpg",".svg",".gz",".tar",".zip"))]
texts = {}
for f in files:
    try: texts[f] = open(f, encoding="utf-8").read()
    except Exception: pass
tokens = collections.defaultdict(collections.Counter)
for f, t in texts.items():
    for tok in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", t):
        tokens[tok][f] += 1
for f in owned:
    tree = ast.parse(texts[f])
    for node in tree.body:
        names = []
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)): names = [node.name]
        elif isinstance(node, ast.Assign): names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        for n in names:
            if n.startswith("__"): continue
            c = tokens[n]
            own = c[f]; other = {k:v for k,v in c.items() if k != f}
            nontest = {k:v for k,v in other.items() if not k.startswith("tests/")}
            if "-v" in sys.argv: print(n, own, len(other), len(nontest))
            if own <= 1 and not other:
                print(f"DEAD? {f}:{node.lineno} {n}")
            elif own <= 1 and not nontest:
                print(f"TESTONLY {f}:{node.lineno} {n} -> {sorted(other)}")
# Second pass: names whose references outside their file are only Markdown or tests, with one own use.
for f in owned:
    tree = ast.parse(texts[f])
    for node in tree.body:
        names = []
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)): names = [node.name]
        elif isinstance(node, ast.Assign): names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        for n in names:
            c = tokens[n]
            code = {k for k in c if k != f and not k.startswith("tests/") and not k.endswith(".md")}
            if c[f] <= 1 and not code:
                print(f"NOCODE {f}:{node.lineno} {n} -> {sorted(k for k in c if k != f)}")
