# ABOUTME: Finds function-local names assigned but never read, unused nested defs, and unused methods.
# ABOUTME: Produces candidates for manual review; it does not model dynamic access.
import ast, sys, re, subprocess, collections
owned = open(sys.argv[1]).read().split()
alltext = "\n".join(open(f).read() for f in subprocess.run(["git","ls-files","*.py","*.ts","*.js","*.cjs","*.yaml","*.patch"],capture_output=True,text=True).stdout.split() if not f.startswith(("docs/verification/","docs/agents/","docs/history/")))
tokcount = collections.Counter(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", alltext))
for f in owned:
    tree = ast.parse(open(f).read())
    for fn in ast.walk(tree):
        if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)): continue
        stores, loads = {}, set()
        nonlocal_names = set()
        for node in ast.walk(fn):
            if isinstance(node, (ast.Global, ast.Nonlocal)): nonlocal_names.update(node.names)
            if isinstance(node, ast.Name):
                if isinstance(node.ctx, ast.Store): stores.setdefault(node.id, node.lineno)
                else: loads.add(node.id)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node is not fn:
                stores.setdefault(node.id if hasattr(node,'id') else node.name, node.lineno)
        # locals()/vars usage disables
        if "locals" in loads or "vars" in loads: continue
        for n, ln in stores.items():
            if n not in loads and n != "_" and not n.startswith("_unused") and n not in nonlocal_names:
                print(f"LOCAL {f}:{ln} {fn.name}.{n}")
    for cls in ast.walk(tree):
        if isinstance(cls, ast.ClassDef):
            for m in cls.body:
                if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef)) and not m.name.startswith("__") and tokcount[m.name] <= 1:
                    print(f"METHOD {f}:{m.lineno} {cls.name}.{m.name}")
