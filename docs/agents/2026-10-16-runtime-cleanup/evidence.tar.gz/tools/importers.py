# ABOUTME: Lists every tracked Python import of selected names from selected bridge modules.
# ABOUTME: Also reports attribute access and getattr string lookups on those modules.
import ast, sys, subprocess
pairs = [p.split(":") for p in sys.argv[1:]]
files = subprocess.run(["git","ls-files","*.py"],capture_output=True,text=True).stdout.split()
for f in files:
    try: tree = ast.parse(open(f).read())
    except Exception as e: print("PARSEFAIL", f, e); continue
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            mod = node.module.split(".")[-1]
            for m,n in pairs:
                if mod == m and any(a.name == n or a.name == "*" for a in node.names):
                    print(f"IMPORTFROM {f}:{node.lineno} {m}.{n}")
        if isinstance(node, ast.Attribute):
            for m,n in pairs:
                if node.attr == n and isinstance(node.value, ast.Name) and node.value.id in (m,):
                    print(f"ATTR {f}:{node.lineno} {m}.{n}")
        if isinstance(node, ast.Constant) and isinstance(node.value,str):
            for m,n in pairs:
                if node.value == n and n not in ("Path","Any","json"):
                    print(f"STRING {f}:{node.lineno} '{n}'")
