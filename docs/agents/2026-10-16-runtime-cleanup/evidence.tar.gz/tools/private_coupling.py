# ABOUTME: Lists cross-module imports of underscore-prefixed names among tracked Python files.
# ABOUTME: Groups by provider module and name so shared private helpers are visible.
import ast, subprocess, collections
files = [f for f in subprocess.run(["git","ls-files","*.py"],capture_output=True,text=True).stdout.split() if not f.startswith(("docs/",))]
uses = collections.defaultdict(list)
for f in files:
    try: tree = ast.parse(open(f).read())
    except Exception: continue
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            for a in node.names:
                if a.name.startswith("_") and not a.name.startswith("__"):
                    uses[(node.module.split(".")[-1], a.name)].append(f)
for (m,n), fs in sorted(uses.items(), key=lambda x: -len(x[1])):
    print(f"{len(fs):3d} {m}.{n}: {' '.join(sorted(set(x.split('/')[-1] for x in fs)))}")
