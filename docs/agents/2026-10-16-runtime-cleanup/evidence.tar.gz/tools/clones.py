# ABOUTME: Finds repeated windows of eight or more normalized source lines across owned modules.
# ABOUTME: Reports each repeated window once with its locations for manual comparison.
import sys, collections, re
W = int(sys.argv[2]) if len(sys.argv) > 2 else 8
index = collections.defaultdict(list)
for f in open(sys.argv[1]).read().split():
    lines = [(i+1, re.sub(r"\s+", " ", l.strip())) for i, l in enumerate(open(f))]
    lines = [(n, l) for n, l in lines if l and not l.startswith("#") and len(l) > 3]
    for k in range(len(lines) - W + 1):
        key = "\n".join(l for _, l in lines[k:k+W])
        index[key].append(f"{f.split('/')[-1]}:{lines[k][0]}")
seen = set()
for key, locs in index.items():
    if len(locs) > 1:
        sig = tuple(sorted({l.split(':')[0] for l in locs}))
        first = locs[0]
        print(len(locs), locs[:4])
