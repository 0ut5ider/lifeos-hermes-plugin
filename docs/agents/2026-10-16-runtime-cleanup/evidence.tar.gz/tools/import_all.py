# ABOUTME: Imports every owned bridge module and prints one status line per module.
# ABOUTME: Used to compare import behavior of the starting and edited trees.
import importlib, sys, traceback
for line in open(sys.argv[1]):
    name = line.strip()[:-3].replace('/', '.')
    try:
        importlib.import_module(name); print('OK', name)
    except BaseException as error:
        print('FAIL', name, type(error).__name__, str(error)[:160])
