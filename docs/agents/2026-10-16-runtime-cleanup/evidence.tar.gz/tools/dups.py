# ABOUTME: Finds structurally identical function bodies across owned Python modules.
# ABOUTME: Compares AST dumps without names or line numbers, ignoring tiny functions.
import ast, sys, collections
owned = open(sys.argv[1]).read().split()
groups = collections.defaultdict(list)
for f in owned:
    tree = ast.parse(open(f).read())
    for fn in ast.walk(tree):
        if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
            body = ast.Module(body=fn.body, type_ignores=[])
            key = ast.dump(ast.Module(body=[ast.arguments(**{k: getattr(fn.args,k) for k in fn.args._fields})] if False else fn.body, type_ignores=[]))
            sig = ast.dump(fn.args)
            size = sum(1 for _ in ast.walk(body))
            if size >= 25:
                groups[(sig, key)].append(f"{f.split('/')[-1]}:{fn.lineno}:{fn.name}")
for k, v in sorted(groups.items(), key=lambda x: -len(x[1])):
    if len(v) > 1: print(len(v), v)
