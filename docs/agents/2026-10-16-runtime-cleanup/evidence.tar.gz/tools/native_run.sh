#!/bin/bash
# ABOUTME: Runs Bun-gated native hook suites against a disposable copy of the reference fixture.
# ABOUTME: Takes the tree to test and the scratch fixture directory as arguments.
TREE=$1; FIX=$2
RC_TREE=$TREE LIFEOS_GUARD_SOURCE=$FIX LIFEOS_AGENT_INVOCATION_PATH=$FIX/hooks/AgentInvocation.hook.ts \
  LIFEOS_VERSION_DRIFT_PATH=$FIX/hooks/VersionDrift.hook.ts LIFEOS_CHECKPOINT_SOURCE=$FIX \
  /tmp/rc_tools/runtests.sh $(cat /tmp/rc_tools/native_suites.txt)
