# ABOUTME: Summarizes cleanup changes against the committed starting tree.
# ABOUTME: Flags release-input edits and missing component test names for review.
import ast
import json
from pathlib import Path
import re
import subprocess

repository = Path('/home/outsider/Projects/Hermes_agent/LifeOS_plugin')
base = '728cd17a94607ec4c119419c052060582a8b75af'

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=repository, text=True, stderr=subprocess.PIPE)

changed = git('diff', '--name-only', base, 'HEAD').splitlines()
protected = [name for name in changed if name.startswith(('patches/', 'lifeos_hook_bridge/patches/'))
    or name in {'VERSION', 'lifeos_hook_bridge/plugin.yaml', 'optional/lifeos_release_manager/plugin.yaml'}
    or name.endswith('/dashboard/manifest.json')]
component_tests = []
python_changes = []
for name in changed:
    if not name.endswith(('.py', '.cjs')) or not (repository / name).exists():
        continue
    try:
        before = git('show', base + ':' + name)
    except subprocess.CalledProcessError:
        before = ''
    after = (repository / name).read_text()
    if name.startswith('tests/') and name.endswith('.cjs'):
        pattern = r'\btest\(\s*([\'"])(.*?)\1'
        old = [match[1] for match in re.findall(pattern, before)]
        new = [match[1] for match in re.findall(pattern, after)]
        component_tests.append({'file': name, 'before_literal_tests': len(old),
            'after_literal_tests': len(new), 'missing_literal_names': sorted(set(old) - set(new))})
    elif name.endswith('.py') and not name.startswith('tests/'):
        def definitions(source):
            return {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(source).body
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
        old, new = definitions(before), definitions(after)
        python_changes.append({'file': name, 'removed_definitions': sorted(set(old) - set(new)),
            'added_definitions': sorted(set(new) - set(old)),
            'changed_definitions': sorted(key for key in old.keys() & new.keys() if old[key] != new[key])})

result = {'base': base, 'head': git('rev-parse', 'HEAD').strip(), 'changed_paths': changed,
    'protected_path_changes': protected, 'component_test_names': component_tests,
    'python_definition_changes': python_changes,
    'limit': 'Static scope aid only. Test-name retention does not prove assertion or behavior equivalence.'}
print(json.dumps(result, indent=2))
