# ABOUTME: Compares the extracted 0.7.2 fixture with its immutable release archive.
# ABOUTME: Reports source changes and generated files without changing either input.
from pathlib import Path
import hashlib
import json
import stat
import tarfile

cache = Path(__file__).parent
base = Path('/home/outsider/.cache/lifeos-release-0.7.2-20261016/packages')
archive = base / '0.7.2-b257d29f.tgz'
package = base / '0.7.2-b257d29f'
expected_digest = '293cfa2c6593b597c327fb8ad11f458d3e374352552dfbe7f4dbba5cd7e67265'
with archive.open('rb') as stream:
    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
expected = set()
missing, changed, modes = [], [], []
with tarfile.open(archive, 'r|gz') as source:
    for member in source:
        if not member.isfile():
            continue
        expected.add(member.name)
        target = package / member.name
        if target.is_symlink() or not target.is_file():
            missing.append(member.name)
            continue
        with source.extractfile(member) as original, target.open('rb') as actual:
            if hashlib.file_digest(original, 'sha256').digest() != hashlib.file_digest(actual, 'sha256').digest():
                changed.append(member.name)
        if stat.S_IMODE(target.stat().st_mode) != member.mode:
            modes.append(member.name)
actual = {path.relative_to(package).as_posix() for path in package.rglob('*') if path.is_file() and not path.is_symlink()}
extra = sorted(actual - expected)
receipt = {'archive_sha256': digest, 'archive_sha256_matches': digest == expected_digest,
    'archive_bytes': archive.stat().st_size, 'archived_regular_files': len(expected),
    'missing_files': missing, 'changed_files': changed, 'changed_modes': modes,
    'extra_regular_files': extra,
    'status': 'PASS' if digest == expected_digest and not (missing or changed or modes or extra) else 'FAIL',
    'limit': 'Directory modification times can change. All archived regular file contents and modes are compared.'}
(cache / 'primary-package-integrity.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'extra_regular_files'} | {'extra_regular_file_count': len(extra)}))
raise SystemExit(receipt['status'] != 'PASS')
