# ABOUTME: Runs cleanup checks against synthetic fixtures with the frozen Python environment.
# ABOUTME: Records command status and completion without selecting software or touching live profiles.
import json
import os
from pathlib import Path
import subprocess
import sys
import time

cache = Path(__file__).parent
repository = Path('/home/outsider/Projects/Hermes_agent/LifeOS_plugin')
package = Path('/home/outsider/.cache/lifeos-release-0.7.2-20261016/packages/0.7.2-b257d29f')
base = Path('/home/outsider/.cache/lifeos-daily-promotion-20261014')
native = Path('/home/outsider/.cache/lifeos-release-0.5.0-20261014/candidate-fixture-04efe633/account/.hermes/.lifeos-releases/6118299dea37462094bcb7d411effb73/reference-home/.claude')
python = base / 'frozen-test-environment/bin/python'
label, *modules = sys.argv[1:]
command = [str(python), '-W', 'error::ResourceWarning', '-m', 'unittest', '-v', *modules]
environment = dict(os.environ, TZ='UTC', PYTHONDONTWRITEBYTECODE='1',
    PATH='/home/outsider/.cache/lifeos-pulse-editor-20261014/tool-bin' + os.pathsep + os.environ['PATH'],
    PYTHONPATH=os.pathsep.join(map(str, (repository, repository / 'tests', package / 'hermes'))),
    LIFEOS_HERMES_SOURCE=str(package / 'hermes'), LIFEOS_MEMORY_SOURCE=str(native),
    LIFEOS_TASK_HOOK_PATH=str(native / 'hooks/TaskGovernance.hook.ts'), LIFEOS_FRESH_SOURCE=str(package / 'lifeos'),
    LIFEOS_TAB_STATE_SOURCE=str(native), LIFEOS_LATEST_HERMES_SOURCE=str(base / 'upstream-hermes'),
    LIFEOS_HARVEST_CONTROL_SOURCE=str(base / 'control-lifeos-install'),
    LIFEOS_FRESHNESS_CONTROL_SOURCE=str(base / 'control-lifeos-install'),
    LIFEOS_HERMES_REBUILD_SOURCE=str(package / 'hermes'), LIFEOS_MANAGED_REFERENCE=str(native),
    LIFEOS_MANAGED_FRESH_OPERATION=str(base / 'historical-fixture-040/account/.hermes/.lifeos-releases/98ecab3f82ed4689a59a965a04ba7b2c'),
    LIFEOS_MANAGED_TEMPLATE_ORIGINALS=str(native.parent.parent / 'fresh-templates/template-originals'),
    LIFEOS_TEST_PYTHON=str(python), PYTHON=str(python))
started = time.monotonic()
receipt = {'label': label, 'command': command, 'modules': modules,
    'head_before': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repository, text=True).strip(),
    'memory_source': str(native), 'freshness_control_source': str(base / 'control-lifeos-install'),
    'qualification': 'Local source checks only. No installed or exact-archive qualification.'}
try:
    with (cache / (label + '.txt')).open('w') as output:
        result = subprocess.run(command, cwd=repository, env=environment, stdout=output, stderr=subprocess.STDOUT, timeout=1800)
    receipt['exit'] = result.returncode
except Exception as error:
    receipt.update(exit=1, error_type=type(error).__name__, error=str(error))
finally:
    receipt['elapsed_seconds'] = time.monotonic() - started
    receipt['head_after'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repository, text=True).strip()
    (cache / (label + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    (cache / (label + '.done')).write_text(str(receipt['exit']) + '\n')
raise SystemExit(receipt['exit'])
