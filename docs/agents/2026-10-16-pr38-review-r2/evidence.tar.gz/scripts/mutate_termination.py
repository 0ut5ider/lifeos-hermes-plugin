# ABOUTME: Confirms that the bounded termination assertion detects a surviving grandchild.
# ABOUTME: Mutates only the in-process test subject and always kills its owned process group.
import json,os,signal,sys,unittest
from pathlib import Path
import lifeos_hook_bridge.memory_owner_jobs as jobs
from test_memory_owner_job_processes import MemoryOwnerJobProcessTests
seen=[];original=MemoryOwnerJobProcessTests.assert_stopped

def inspect(self):
 seen.extend(json.loads(self.pids.read_text()))
 return original(self)
def parent_only(process):
 process.kill();process.wait()
MemoryOwnerJobProcessTests.assert_stopped=inspect
jobs._terminate=parent_only
try:
 result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([MemoryOwnerJobProcessTests('test_deadline_kills_the_actual_child_and_grandchild')]))
 assert len(result.failures)==1 and not result.errors and 'still runs' in result.failures[0][1]
 print('PASS: the mutation that leaves the grandchild alive is detected.')
finally:
 if len(seen)==2:
  try:
   if os.getpgid(seen[1])==seen[0]:os.killpg(seen[0],signal.SIGKILL)
  except ProcessLookupError:pass
