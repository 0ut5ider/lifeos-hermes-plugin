# ABOUTME: Checks native LifeOS capability feedback after a failed Hermes command.
# ABOUTME: Runs the installed AlgorithmNudge through the bridge in a disposable home.

import json
import os
import shutil
import tempfile
import time
import unittest
from pathlib import Path

from lifeos_hook_bridge.bridge import HookBridge


HOOK_PATH = os.environ.get("LIFEOS_ALGORITHM_NUDGE_PATH")


@unittest.skipUnless(HOOK_PATH and shutil.which("bun"), "LifeOS AlgorithmNudge and Bun are required")
class NativeAlgorithmNudgeTests(unittest.TestCase):
    def test_indexed_skill_phrase_returns_route_nudge(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            root = home / ".claude"
            root.mkdir()
            state_dir = root / "LIFEOS/MEMORY/STATE"
            state_dir.mkdir(parents=True)
            (state_dir / "skill-usewhen-index.json").write_text(json.dumps({
                "builtAt": int(time.time() * 1000),
                "entries": [{"skill": "memory-debugging", "phrases": ["investigate memory leak"]}],
            }))
            settings = root / "settings.json"
            settings.write_text(json.dumps({"hooks": {"UserPromptSubmit": [{"hooks": [
                {"type": "command", "command": f"bun {HOOK_PATH}"},
            ]}]}}))
            bridge = HookBridge(settings, root)
            bridge.environment["HOME"] = str(home)
            try:
                result = bridge.pre_llm_call(
                    "Please investigate memory leak in the process", session_id="skill-route-probe",
                )
            finally:
                bridge.close()

            self.assertIn("USE WHEN of: memory-debugging", result["context"])
            state = json.loads((state_dir / "isa-nudge/skill-route-probe.json").read_text())
            self.assertIn("route:memory-debugging", state["lastNudgeAt"])

    def test_depth_directive_returns_one_prompt_nudge(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            root = home / ".claude"
            root.mkdir()
            settings = root / "settings.json"
            settings.write_text(json.dumps({"hooks": {"UserPromptSubmit": [{"hooks": [
                {"type": "command", "command": f"bun {HOOK_PATH}"},
            ]}]}}))
            bridge = HookBridge(settings, root)
            bridge.environment["HOME"] = str(home)
            try:
                first = bridge.pre_llm_call("go deep", session_id="depth-probe")
                second = bridge.pre_llm_call("go deep", session_id="depth-probe")
            finally:
                bridge.close()

            self.assertIn("He directed depth", first["context"])
            self.assertIsNone(second)
            state = json.loads((root / "LIFEOS/MEMORY/STATE/isa-nudge/depth-probe.json").read_text())
            self.assertIn("depth", state["lastNudgeAt"])

    def test_broken_capability_failure_returns_one_nudge(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            root = home / ".claude"
            root.mkdir()
            manifest = home / "capabilities.json"
            manifest.write_text(json.dumps({"capabilities": {"codex": {"state": "broken"}}}))
            settings = root / "settings.json"
            settings.write_text(json.dumps({"hooks": {"PostToolUseFailure": [{"hooks": [
                {"type": "command", "command": f"bun {HOOK_PATH}"},
            ]}]}}))
            bridge = HookBridge(settings, root)
            bridge.environment["HOME"] = str(home)
            bridge.environment["LIFEOS_CAPABILITIES_PATH"] = str(manifest)
            try:
                feedback = [bridge.post_tool_call(
                    "terminal", {"command": "codex --version"}, "Exit code 1", session_id="broken-cap",
                    status="error", error_message="Exit code 1",
                ) for _ in range(2)]
            finally:
                bridge.close()

            self.assertIn("\"codex\" capability", feedback[0])
            self.assertIn("Doctor has as BROKEN", feedback[0])
            self.assertIsNone(feedback[1])
