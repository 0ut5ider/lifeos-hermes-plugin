// ABOUTME: Differential probe of refactored paths that the suite does not pin, run against one exported bundle copy.
// ABOUTME: Prints observable states as JSON so the old and new bundles can be compared line by line.
const path = require('node:path');
const root = path.resolve(process.argv[2]);
const { component, find, findAll, loadDashboard, settle, text } = require(path.join(root, 'tests/support/dashboard_sdk.cjs'));

function deferred() {
  let resolve, reject;
  const promise = new Promise((a, b) => { resolve = a; reject = b; });
  return { promise, resolve, reject };
}
const out = {};

async function installationRefreshFailure(label, installation) {
  const refresh = deferred();
  let posted = false;
  const fetchJSON = (url, init) => {
    if (init?.method === 'POST') { posted = true; return Promise.resolve({ installed_version: '7.40.4', mounted: true }); }
    if (posted && (url.endsWith('/installation') || url.endsWith('/version-drift'))) return refresh.promise;
    if (url.endsWith('/installation')) return Promise.resolve({ version: '7.40.4', ...installation });
    if (url.endsWith('/version-drift')) return Promise.resolve({ state: 'missing' });
    if (url.endsWith('/host-patch') || url.endsWith('/update')) return Promise.resolve({ state: 'none' });
    if (url.includes('/api/model/options')) return Promise.resolve({ providers: [] });
    return Promise.resolve({ fields: [] });
  };
  const render = loadDashboard('bridge', { fetchJSON, window: { setTimeout: () => 0 } }).mount();
  await settle();
  const section = () => find(render(), (node) => node.props.id === 'lifeos_installation');
  const status = () => find(section(), (node) => node.type === 'p' && node.props.role === 'status' && node.props.className === 'mt-3');
  find(section(), (node) => node.type === 'button' && node.children.includes(label)).props.onClick();
  for (let turn = 0; turn < 4; turn++) await settle();
  const pending = { busy: findAll(section(), (node) => node.type === 'button').every((node) => node.props.disabled === true), status: status() ? text(status()) : null };
  refresh.reject(new Error('synthetic refresh refusal'));
  for (let turn = 0; turn < 4; turn++) await settle();
  const settled = { busy: findAll(section(), (node) => node.type === 'button').every((node) => node.props.disabled === true), status: status() ? text(status()) : null };
  return { pending, settled };
}

async function memoryPanel(respond) {
  const app = loadDashboard('bridge', { fetchJSON: respond, window: { crypto: require('node:crypto').webcrypto } });
  const render = app.mount(component(app.preview(), 'MemoryPreferences'));
  await settle();
  return render;
}
const message = (view) => { const node = find(view, (n) => n.type === 'p' && n.props.role === 'status'); return node ? text(node) : null; };

async function connectionRefreshFailure() {
  let shared = false;
  const refresh = deferred();
  const render = await memoryPanel((url, init) => {
    if (url.endsWith('/memory/sharing')) { shared = true; return Promise.resolve({ status: 'ok', sharing_enabled: true }); }
    if (shared) return refresh.promise;
    return Promise.resolve({ state: 'prepared', native_health: 'ok', sharing_enabled: false, connections: [], remaining_gates: {} });
  });
  const pending = find(render(), (n) => n.type === 'button' && n.children.includes('Enable memory sharing')).props.onClick();
  for (let turn = 0; turn < 3; turn++) await settle();
  const during = { busy: find(render(), (n) => n.type === 'button' && n.children.includes('Check memory status'))?.props.disabled, message: message(render()) };
  refresh.reject(new Error('synthetic status refusal'));
  await pending;
  const after = { busy: find(render(), (n) => n.type === 'button' && n.children.includes('Check memory status'))?.props.disabled, message: message(render()) };
  return { during, after };
}

async function searchMicrotasks() {
  const response = deferred();
  const render = await memoryPanel((url) => url.endsWith('/memory/review') ? response.promise :
    Promise.resolve({ state: 'prepared', native_health: 'ok', connections: [], remaining_gates: {} }));
  find(render(), (n) => n.type === 'input' && n.props.id === 'memory_query').props.onChange({ target: { value: 'x' } });
  const pending = find(render(), (n) => n.type === 'form' && n.props.id === 'memory_search').props.onSubmit({ preventDefault() {} });
  let done = false;
  pending.then(() => { done = true; });
  response.resolve({ status: 'ok', results: [{ content: 'probe fact', reference: { id: 'p', revision: 1 }, writer: 'owner' }] });
  const steps = [];
  for (let step = 0; step < 8 && !done; step++) {
    await Promise.resolve();
    const view = render();
    steps.push({ step, results: Boolean(find(view, (n) => n.type === 'p' && n.children.includes('probe fact'))),
      busy: find(view, (n) => n.type === 'button' && n.children.includes('Search memories')).props.disabled });
  }
  const distinct = steps.filter((s, i) => i === 0 || JSON.stringify({ r: s.results, b: s.busy }) !== JSON.stringify({ r: steps[i - 1].results, b: steps[i - 1].busy }));
  return { distinctStates: distinct.map((s) => ({ results: s.results, busy: s.busy })) };
}

async function freshStoreReloadFailure() {
  let removed = false;
  const fetchJSON = (url, init) => {
    if (init?.method === 'DELETE') { removed = true; return Promise.resolve({ removed: true }); }
    if (removed && url.endsWith('/memory/fresh/status')) return Promise.reject(new Error('synthetic list refusal'));
    if (url.endsWith('/memory/fresh/status')) return Promise.resolve({ busy: false, stores: [{ identifier: 'a'.repeat(32), state: 'failed', error: 'x' }] });
    if (url.endsWith('/installation/selection')) return Promise.resolve({ configured: false, home: '/h', running_home: '/h', job: { state: 'none' } });
    return Promise.resolve({ state: 'not_configured', remaining_gates: {}, connections: [] });
  };
  const app = loadDashboard('bridge', { fetchJSON, window: { crypto: require('node:crypto').webcrypto } });
  const render = app.mount(component(app.preview(), 'FreshStores'));
  await settle();
  await find(render(), (n) => n.type === 'button' && text(n).startsWith('Remove')).props.onClick();
  const notice = find(render(), (n) => n.type === 'p' && n.props.role === 'status');
  return { notice: notice ? text(notice) : null, removeDisabled: find(render(), (n) => n.type === 'button' && text(n).startsWith('Remove'))?.props.disabled };
}

(async () => {
  out.installRefreshFailure = await installationRefreshFailure('Install prepared LifeOS',
    { lifeos: 'missing', candidate_ready: true, candidate_commit: 'a'.repeat(40), candidate_patch_count: 1 });
  out.finalizeRefreshFailure = await installationRefreshFailure('Finish LifeOS setup',
    { lifeos: 'installed', hermes: 'patched_hooks_present', setup_baseline_exists: false, candidate_ready: true });
  out.mountRecoverRefreshFailure = await installationRefreshFailure('Restore interrupted mount',
    { lifeos: 'installed', hermes: 'patched_hooks_present', setup_baseline_exists: false, mount: { recovery_required: true } });
  out.connectionRefreshFailure = await connectionRefreshFailure();
  out.searchMicrotasks = await searchMicrotasks();
  out.freshStoreReloadFailure = await freshStoreReloadFailure();
  for (const [key, value] of Object.entries(out)) console.log(key + ' ' + JSON.stringify(value));
})().catch((error) => { console.error('PROBE ERROR', error); process.exitCode = 1; });
