# ABOUTME: Applies extra single mutations that probe each new pending-refresh assertion in an exported bundle copy.
# ABOUTME: Never touches the shared checkout; pass the export root as the only argument.
import pathlib
import subprocess
import sys

root = pathlib.Path(sys.argv[1]).resolve()
bundle = root / "lifeos_hook_bridge/dashboard/dist/index.js"
original = bundle.read_text()

mutations = {
    "apply-refresh-not-returned": (
        "return SDK.fetchJSON(installationEndpoint).then(function (status) {",
        "SDK.fetchJSON(installationEndpoint).then(function (status) {"),
    "finalize-refresh-not-returned": (
        "return Promise.all([SDK.fetchJSON(installationEndpoint), SDK.fetchJSON(baselineEndpoint)]).then(function (results) {\n          setInstallation(results[0]);\n          setBaseline(results[1]);\n          setInstallationStatus(\"LifeOS is mounted",
        "Promise.all([SDK.fetchJSON(installationEndpoint), SDK.fetchJSON(baselineEndpoint)]).then(function (results) {\n          setInstallation(results[0]);\n          setBaseline(results[1]);\n          setInstallationStatus(\"LifeOS is mounted"),
    "recover-refresh-not-returned": (
        "return SDK.fetchJSON(installationEndpoint).then(function (result) {\n          setInstallation(result);\n          setInstallationStatus(\"The previous",
        "SDK.fetchJSON(installationEndpoint).then(function (result) {\n          setInstallation(result);\n          setInstallationStatus(\"The previous"),
    "installation-refresh-error-swallowed": (
        "SDK.fetchJSON(url, { method: \"POST\" }).then(succeed)",
        "SDK.fetchJSON(url, { method: \"POST\" }).then(function (result) { return Promise.resolve(succeed(result)).catch(function () {}); })"),
    "connection-message-before-refresh": (
        "async function showConnectionChange(result) {\n      setMemory(await SDK.fetchJSON(memoryEndpoint));\n      setMessage(",
        "async function showConnectionChange(result) {\n      const refreshed = SDK.fetchJSON(memoryEndpoint);\n      setMessage("),
    "connection-refresh-error-swallowed": (
        "async function showConnectionChange(result) {\n      setMemory(await SDK.fetchJSON(memoryEndpoint));",
        "async function showConnectionChange(result) {\n      try { setMemory(await SDK.fetchJSON(memoryEndpoint)); } catch (error) {}"),
    "change-request-not-awaited": (
        "await request();\n        setNotice(done);", "request();\n        setNotice(done);"),
    "change-load-not-awaited": (
        "setNotice(done);\n        await load();", "setNotice(done);\n        load();"),
}
# The connection-message-before-refresh mutation needs the refresh awaited after the message.
extra_tail = {
    "connection-message-before-refresh": (
        "\"Memory sharing is \" + (result.sharing_enabled ? \"enabled.\" : \"disabled.\"));\n    }",
        "\"Memory sharing is \" + (result.sharing_enabled ? \"enabled.\" : \"disabled.\"));\n      setMemory(await refreshed);\n    }"),
}

try:
    for name, (old, new) in mutations.items():
        count = original.count(old)
        mutated = original.replace(old, new)
        if name in extra_tail:
            tail_old, tail_new = extra_tail[name]
            if mutated.count(tail_old) != 1:
                print(f"MUTATION {name}: tail anchor count {mutated.count(tail_old)}, skipped")
                continue
            mutated = mutated.replace(tail_old, tail_new)
        if count != 1:
            print(f"MUTATION {name}: anchor count {count}, skipped")
            continue
        bundle.write_text(mutated)
        check = subprocess.run(["node", "--check", str(bundle)], capture_output=True, text=True)
        run = subprocess.run(["node", "--test", *sorted(str(p) for p in (root / "tests").glob("*.cjs"))],
                             cwd=root, capture_output=True, text=True)
        fails = [line for line in run.stdout.splitlines() if line.startswith("not ok")]
        summary = [line for line in run.stdout.splitlines() if line.startswith("# fail")]
        print(f"MUTATION {name}: syntax exit {check.returncode}; {summary[0] if summary else 'no summary'}")
        for line in fails:
            print("   " + line)
finally:
    bundle.write_text(original)
