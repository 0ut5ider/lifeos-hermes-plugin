# ABOUTME: Applies single mutations to an isolated exported copy of the bridge bundle and runs the Node suite.
# ABOUTME: Never touches the shared checkout; the copy lives under this review's scratch directory.
import pathlib
import subprocess
import sys

root = pathlib.Path(sys.argv[1]).resolve()
bundle = root / "lifeos_hook_bridge/dashboard/dist/index.js"
original = bundle.read_text()

mutations = {
    "installation-status-clear-removed": (
        'setInstallationBusy(true);\n      setInstallationStatus("");\n      SDK.fetchJSON(url',
        'setInstallationBusy(true);\n      SDK.fetchJSON(url'),
    "installation-succeed-not-chained": (
        "SDK.fetchJSON(url, { method: \"POST\" }).then(succeed)",
        "SDK.fetchJSON(url, { method: \"POST\" }).then(function (result) { succeed(result); })"),
    "proposals-handler-swapped-to-search": (
        "arguments: {} }, showProposals);", "arguments: {} }, showSearch);"),
    "claim-handler-swapped-to-connection": (
        "undefined, showClaim);", "undefined, showConnectionChange);"),
    "preview-handler-swapped-to-adoption": (
        '"POST", {}, showAdoptionPreview);', '"POST", {}, showAdoption);'),
    "action-show-not-awaited": ("await show(await", "show(await"),
    "change-notice-before-request": (
        "await request();\n        setNotice(done);", "setNotice(done);\n        await request();"),
    "change-busy-not-set": (
        "async function change(request, done) {\n      setBusy(true);",
        "async function change(request, done) {"),
    "connection-refresh-not-awaited": (
        "async function showConnectionChange(result) {\n      setMemory(await SDK.fetchJSON(memoryEndpoint));",
        "async function showConnectionChange(result) {\n      SDK.fetchJSON(memoryEndpoint).then(setMemory);"),
    "decision-refresh-not-awaited": (
        "const pending = await postJSON(memoryEndpoint", "const pending = postJSON(memoryEndpoint"),
    "choose-headers-always": (
        "...(body === undefined ? {} : { headers: { \"Content-Type\": \"application/json\" }, body: JSON.stringify(body) }) });\n      }, started);",
        "headers: { \"Content-Type\": \"application/json\" }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });\n      }, started);"),
    "read-scopes-order-swapped": (
        'if (principal) read.push("principal");\n    if (assistant) read.push("assistant");',
        'if (assistant) read.push("assistant");\n    if (principal) read.push("principal");'),
}

try:
    for name, (old, new) in mutations.items():
        count = original.count(old)
        if count != 1:
            print(f"MUTATION {name}: anchor count {count}, skipped")
            continue
        bundle.write_text(original.replace(old, new))
        run = subprocess.run(["node", "--test", *sorted(str(p) for p in (root / "tests").glob("*.cjs"))],
                             cwd=root, capture_output=True, text=True)
        fails = [line for line in run.stdout.splitlines() if line.startswith("not ok")]
        summary = [line for line in run.stdout.splitlines() if line.startswith("# fail")]
        print(f"MUTATION {name}: {summary[0] if summary else 'no summary'}")
        for line in fails:
            print("   " + line)
finally:
    bundle.write_text(original)
