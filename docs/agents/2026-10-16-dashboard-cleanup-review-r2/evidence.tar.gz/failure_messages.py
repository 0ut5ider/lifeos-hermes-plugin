# ABOUTME: Applies the four previously surviving review mutations one at a time and prints which assertion fails.
# ABOUTME: Works only on the export passed as the first argument and restores the bundle afterwards.
import pathlib, re, subprocess, sys
root = pathlib.Path(sys.argv[1]).resolve()
bundle = root / "lifeos_hook_bridge/dashboard/dist/index.js"
original = bundle.read_text()
source = (pathlib.Path(__file__).parent / "mutate.py").read_text()
block = source[source.index("mutations = {"):source.index("\n}\n") + 3]
scope = {}
exec(block, scope)
names = ["installation-status-clear-removed", "installation-succeed-not-chained",
         "change-notice-before-request", "connection-refresh-not-awaited"]
files = {"installation": "tests/test_dashboard_ui.cjs", "change": "tests/test_fresh_store_ui.cjs",
         "connection": "tests/test_memory_dashboard_ui.cjs"}
try:
    for name in names:
        old, new = scope["mutations"][name]
        assert original.count(old) == 1
        bundle.write_text(original.replace(old, new))
        run = subprocess.run(["node", "--test", files[name.split("-")[0]]], cwd=root, capture_output=True, text=True)
        out = run.stdout + run.stderr
        print(f"== {name}: exit {run.returncode}")
        for line in out.splitlines():
            if re.search(r"^not ok|error: |message: |unhandled|\+ actual|- expected|^\s+[+-] ", line, re.I):
                print("   " + line.rstrip()[:200])
finally:
    bundle.write_text(original)
