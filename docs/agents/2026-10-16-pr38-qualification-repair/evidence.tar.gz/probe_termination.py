# ABOUTME: Measures grandchild exit visibility immediately after real process-group termination.
# ABOUTME: Uses only owned synthetic children and records bounded terminal-state transitions.
import json,os,subprocess,sys,tempfile,time
from pathlib import Path
from lifeos_hook_bridge.memory_owner_jobs import _terminate
c=Path(__file__).parent;rows=[]
def state(pid):
 try:return (Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()[0]
 except (FileNotFoundError,ProcessLookupError):return 'absent'
for n in range(100):
 with tempfile.TemporaryDirectory(dir=c) as d:
  p=Path(d)/'pids';code='import subprocess,sys,time;from pathlib import Path;c=subprocess.Popen([sys.executable,"-c","import time;time.sleep(60)"]);Path(sys.argv[1]).write_text(str(c.pid));time.sleep(60)'
  proc=subprocess.Popen([sys.executable,'-c',code,str(p)],start_new_session=True)
  try:
   end=time.monotonic()+5
   while not p.exists() or not p.read_text():
    assert time.monotonic()<end
    time.sleep(.001)
   grand=int(p.read_text());started=time.monotonic();_terminate(proc);initial=state(grand);samples=[{'elapsed':time.monotonic()-started,'state':initial}]
   while samples[-1]['state'] not in ['Z','absent'] and time.monotonic()-started<5:
    time.sleep(.001);samples.append({'elapsed':time.monotonic()-started,'state':state(grand)})
   rows.append({'round':n,'states':samples})
  finally:
   if proc.poll() is None:_terminate(proc)
v={'rounds':len(rows),'nonterminal_at_return':sum(x['states'][0]['state'] not in ['Z','absent'] for x in rows),'all_terminal_within_5_seconds':all(x['states'][-1]['state'] in ['Z','absent'] for x in rows),'rows':rows}
(c/'termination-timing.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({k:v for k,v in v.items() if k!='rows'}))
